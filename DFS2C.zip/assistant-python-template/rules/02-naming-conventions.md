# Naming Conventions

## Overview

Consistent naming makes code easier to read, understand, and maintain. This document outlines all naming conventions used in the project.

## Python Naming Standards

### File Names

**Pattern:** `snake_case` (all lowercase, words separated by underscores)

```
✅ Good:
- user_service.py
- chat_router.py
- sample_models.py
- openai_adapter.py

❌ Bad:
- UserService.py          # PascalCase
- chatRouter.py           # camelCase
- sample-models.py        # kebab-case (use underscores)
- svc.py                  # Abbreviations
```

### Class Names

**Pattern:** `PascalCase` (capitalize first letter of each word, no separators)

```python
# ✅ Good
class UserService:
    pass

class ChatRouter:
    pass

class OpenAIStreamAdapter:
    pass

class SampleRequest(BaseModel):
    pass

# ❌ Bad
class user_service:         # snake_case
    pass

class chatRouter:           # camelCase
    pass

class openAI_Adapter:       # Mixed case
    pass
```

### Function and Method Names

**Pattern:** `snake_case` (all lowercase, words separated by underscores)

```python
# ✅ Good
def get_prompt(city: str) -> str:
    pass

def ask_about_city(city: str, model: str) -> StreamingResponse:
    pass

def create_stream_response(client, messages, model):
    pass

def _build_params(messages, **kwargs):  # Private method
    pass

# ❌ Bad
def GetPrompt(city: str) -> str:        # PascalCase
    pass

def askAboutCity(city, model):          # camelCase
    pass

def createStreamResp(c, m, mod):        # Abbreviations
    pass
```

### Variable Names

**Pattern:** `snake_case` (all lowercase, words separated by underscores)

```python
# ✅ Good
user_message = "Hello"
prompt_tokens = 100
completion_tokens = 200
api_key = os.environ.get("OPENAI_API_KEY")
stream_adapter = OpenAIStreamAdapter()

# ❌ Bad
UserMessage = "Hello"           # PascalCase
promptTokens = 100              # camelCase
pt = 100                        # Abbreviation
x = OpenAIStreamAdapter()       # Non-descriptive
```

### Constant Names

**Pattern:** `UPPER_SNAKE_CASE` (all uppercase, words separated by underscores)

```python
# ✅ Good
DEFAULT_MODEL = "gpt-4o"
MAX_TOKENS = 4096
API_VERSION = "v1"
DEFAULT_TEMPERATURE = 0.7

# ❌ Bad
defaultModel = "gpt-4o"         # camelCase
max_tokens = 4096               # lowercase (looks like variable)
Api_Version = "v1"              # Mixed case
```

### Private Methods/Variables

**Pattern:** Prefix with single underscore `_`

```python
class SampleService:
    def __init__(self):
        self._client = None          # Private variable
        self._cached_results = {}    # Private variable

    def public_method(self):         # Public
        return self._private_method()

    def _private_method(self):       # Private
        pass

    def _validate_input(self, data): # Private helper
        pass
```

**Note:** Double underscore `__` triggers name mangling in Python - avoid unless you specifically need it.

### Parameter Names

Be explicit and descriptive:

```python
# ✅ Good
def ask_about_city(
    city: str,
    model: str = "gpt-4o",
    temperature: float = 0.7,
    max_tokens: int | None = None
):
    pass

def create_stream_response(
    client: AsyncOpenAI,
    messages: List[Dict[str, Any]],
    model: str,
    **kwargs
):
    pass

# ❌ Bad
def ask(c: str, m: str = "gpt"):        # Abbreviations
    pass

def create(cl, msg, mdl, **k):          # Too short
    pass
```

## FastAPI-Specific Naming

### Router Variables

**Pattern:** Name the router variable `router`

```python
# ✅ Good
from fastapi import APIRouter

router = APIRouter(prefix="/sample", tags=["Sample"])

# ❌ Bad
sample_router = APIRouter(...)    # Don't include 'router' in variable name
r = APIRouter(...)                # Too short
```

### Route Endpoint Names

**Pattern:** Verb + noun/description in `snake_case`

```python
# ✅ Good
@router.post("/show/me")
def show_me_how_it_works(request: SampleRequest):
    pass

@router.post("/city")
def ask_about_city(request: CityRequest):
    pass

@router.get("/story")
def stream_story(chunk_size: int = 5):
    pass

@router.get("/users")
def list_users():
    pass

@router.post("/users")
def create_user(request: UserRequest):
    pass

@router.get("/users/{user_id}")
def get_user(user_id: str):
    pass

# ❌ Bad
@router.post("/show")
def show(request):                     # Not descriptive
    pass

@router.post("/city")
def cityHandler(request):              # camelCase
    pass

@router.get("/story")
def s(chunk_size):                     # Too short
    pass
```

### Route Paths

**Pattern:** `kebab-case` for URLs (lowercase, words separated by hyphens)

```python
# ✅ Good
@router.post("/ask-about-city")
@router.get("/user-profile")
@router.post("/generate-summary")

# For hierarchical paths, use forward slashes
@router.get("/api/v1/documents")
@router.post("/chat/stream")

# ❌ Bad
@router.post("/askAboutCity")          # camelCase in URL
@router.get("/user_profile")           # snake_case (use hyphens)
@router.post("/GenerateSummary")       # PascalCase
```

### Tag Names

**Pattern:** Title Case (first letter of each word capitalized)

```python
# ✅ Good
router = APIRouter(prefix="/sample", tags=["Sample Operations"])
router = APIRouter(prefix="/chat", tags=["Chat"])
router = APIRouter(prefix="/users", tags=["User Management"])

# ❌ Bad
router = APIRouter(prefix="/sample", tags=["sample"])  # lowercase
router = APIRouter(prefix="/chat", tags=["CHAT"])      # all caps
```

## Pydantic Model Naming

### Model Class Names

**Pattern:** Descriptive noun + purpose in `PascalCase`

```python
# ✅ Good
class SampleRequest(BaseModel):
    pass

class SampleResponse(BaseModel):
    pass

class CityRequest(BaseModel):
    pass

class UserProfile(BaseModel):
    pass

class ChatMessage(BaseModel):
    pass

# ❌ Bad
class Sample(BaseModel):               # Not specific enough
    pass

class sample_request(BaseModel):       # snake_case
    pass

class Req(BaseModel):                  # Abbreviation
    pass
```

### Model Field Names

**Pattern:** `snake_case` matching JSON field names

```python
# ✅ Good
class CityRequest(BaseModel):
    city: str
    model: str | None
    temperature: float | None
    max_tokens: int | None

# With Field for validation
class SampleRequest(BaseModel):
    city: str = Field(
        ...,
        description="The name of the city",
        min_length=1,
        examples=["Paris"]
    )

# ❌ Bad
class CityRequest(BaseModel):
    City: str                          # PascalCase
    Model: str | None                  # PascalCase
    temp: float | None                 # Abbreviation
```

## Service Class Naming

### Service Class Names

**Pattern:** Descriptive noun + `Service` in `PascalCase`

```python
# ✅ Good
class SampleStreamingService(BaseStreamingService):
    pass

class UserService:
    pass

class ChatService(BaseStreamingService):
    pass

class DocumentProcessingService:
    pass

# ❌ Bad
class SampleService1:                  # Numbers
    pass

class Service:                         # Too generic
    pass

class SampleSvc:                       # Abbreviation
    pass
```

### Service Methods

**Pattern:** Verb-based `snake_case` describing action

```python
# ✅ Good
class SampleService:
    def ask_about_city(self, city: str) -> StreamingResponse:
        pass

    def stream_story(self, chunk_size: int) -> StreamingResponse:
        pass

    def get_user_data(self, user_id: str) -> dict:
        pass

    def validate_input(self, data: dict) -> bool:
        pass

# ❌ Bad
class SampleService:
    def city(self, city):              # Noun, not descriptive
        pass

    def doStream(self, size):          # camelCase
        pass

    def get(self, id):                 # Too generic
        pass
```

## Streaming Infrastructure Naming

### Adapter Class Names

**Pattern:** Provider name + `StreamAdapter`

```python
# ✅ Good
class OpenAIStreamAdapter(StreamAdapter):
    pass

class AnthropicStreamAdapter(StreamAdapter):
    pass

class CohereStreamAdapter(StreamAdapter):
    pass

# ❌ Bad
class OpenAIAdapter:                   # Missing 'Stream'
    pass

class StreamOpenAI:                    # Wrong order
    pass

class OAIStreamAdapter:                # Abbreviation
    pass
```

### Formatter Class Names

**Pattern:** Protocol name + `Formatter`

```python
# ✅ Good
class AISdkFormatter(ProtocolFormatter):
    pass

class ServerSentEventsFormatter(ProtocolFormatter):
    pass

class JsonStreamFormatter(ProtocolFormatter):
    pass

# ❌ Bad
class AISdk:                           # Missing 'Formatter'
    pass

class FormatterAISdk:                  # Wrong order
    pass

class SSEFormatter:                    # Abbreviation (spell it out)
    pass
```

### Streamer Class Names

**Pattern:** Type + `Streamer`

```python
# ✅ Good
class LLMStreamer:
    pass

class TextStreamer:
    pass

# ❌ Bad
class StreamerLLM:                     # Wrong order
    pass

class Streamer:                        # Too generic
    pass
```

## Template Naming

### Template Files

**Pattern:** `snake_case` ending in `.j2`

```
✅ Good:
- prompt.j2
- user_prompt.j2
- chat_system.j2
- document_analysis.j2

❌ Bad:
- Prompt.j2                   # PascalCase
- userPrompt.j2               # camelCase
- template1.j2                # Numbers, not descriptive
- prompt.jinja2               # Use .j2 extension
```

### Template Variables

**Pattern:** `snake_case` matching Python variables

```jinja
{# ✅ Good #}
{{ user_input }}
{{ city_name }}
{{ temperature_setting }}
{{ include_examples }}

{# ❌ Bad #}
{{ UserInput }}               {# PascalCase #}
{{ cityName }}                {# camelCase #}
{{ temp }}                    {# Abbreviation #}
{{ x }}                       {# Not descriptive #}
```

## Test Naming

### Test File Names

**Pattern:** `test_` + module name in `snake_case`

```
✅ Good:
- test_sample_router.py
- test_sample_service.py
- test_formatters.py
- test_openai_adapter.py

❌ Bad:
- sample_test.py              # Should start with test_
- test_Sample.py              # PascalCase
- tests.py                    # Too generic
```

### Test Function Names

**Pattern:** `test_` + what you're testing + expected behavior

```python
# ✅ Good
def test_show_me_endpoint_returns_prompt():
    pass

def test_ask_about_city_streams_response():
    pass

def test_formatter_handles_none_content():
    pass

def test_service_raises_error_on_missing_api_key():
    pass

def test_adapter_converts_chunks_correctly():
    pass

# ❌ Bad
def test_endpoint():                   # Not specific
    pass

def test_1():                          # Numbers
    pass

def testAskAboutCity():                # camelCase
    pass

def test():                            # Too generic
    pass
```

### Test Fixture Names

**Pattern:** Descriptive `snake_case` nouns

```python
# ✅ Good
@pytest.fixture
def sample_client():
    pass

@pytest.fixture
def mock_openai_client():
    pass

@pytest.fixture
def test_messages():
    pass

# ❌ Bad
@pytest.fixture
def fixture1():                        # Numbers
    pass

@pytest.fixture
def c():                               # Too short
    pass

@pytest.fixture
def MockClient():                      # PascalCase
    pass
```

## Environment Variables

**Pattern:** `UPPER_SNAKE_CASE`

```bash
# ✅ Good
OPENAI_API_KEY=your-key
DATABASE_URL=postgresql://...
MAX_WORKERS=4
DEBUG_MODE=true

# ❌ Bad
openai_api_key=your-key        # lowercase
OpenAiApiKey=your-key          # PascalCase
api-key=your-key               # kebab-case
```

## Decorator Names

**Pattern:** Lowercase verb/action

```python
# ✅ Good
@log(__name__)
def endpoint():
    pass

@cache
def expensive_operation():
    pass

@validate_input
def process_data():
    pass

# ❌ Bad
@Log(__name__)                 # PascalCase
    pass

@CACHE                         # All caps
    pass
```

## Common Abbreviations to Avoid

Replace these with full words:

| ❌ Avoid | ✅ Use |
|---------|-------|
| `msg` | `message` |
| `req` | `request` |
| `res` | `response` |
| `param` | `parameter` |
| `val` | `value` |
| `doc` | `document` |
| `cfg` | `config` |
| `str` (variable) | `text`, `content`, `name` |
| `dict` (variable) | `data`, `params`, `options` |
| `temp` | `temperature`, `temporary` |
| `max` | `maximum` |
| `min` | `minimum` |
| `num` | `number`, `count` |

**Exceptions:** Well-known abbreviations in context:
- `id` (identifier) ✅
- `api` (Application Programming Interface) ✅
- `url` (Uniform Resource Locator) ✅
- `html` (HyperText Markup Language) ✅
- `json` (JavaScript Object Notation) ✅
- `llm` (Large Language Model) ✅

## Naming Checklist

Before committing, check that your names:

- [ ] Use appropriate case convention (snake_case, PascalCase, etc.)
- [ ] Are descriptive and self-documenting
- [ ] Avoid abbreviations (except well-known ones)
- [ ] Match existing patterns in the codebase
- [ ] Are pronounceable in English
- [ ] Don't include redundant information (e.g., `user_dict` → `user`)
- [ ] Use consistent vocabulary across the project
- [ ] Follow Python PEP 8 guidelines

## Quick Reference Table

| Element | Convention | Example |
|---------|-----------|---------|
| File | `snake_case` | `user_service.py` |
| Class | `PascalCase` | `UserService` |
| Function | `snake_case` | `get_user()` |
| Variable | `snake_case` | `user_name` |
| Constant | `UPPER_SNAKE_CASE` | `MAX_TOKENS` |
| Private | `_prefix` | `_internal_method()` |
| Router | `router` | `router = APIRouter()` |
| Route Path | `kebab-case` | `/user-profile` |
| Tag | Title Case | `"User Management"` |
| Model | `PascalCase` | `UserRequest` |
| Field | `snake_case` | `user_name: str` |
| Service | `PascalCase` + `Service` | `ChatService` |
| Adapter | Provider + `StreamAdapter` | `OpenAIStreamAdapter` |
| Formatter | Protocol + `Formatter` | `AISdkFormatter` |
| Template | `snake_case.j2` | `user_prompt.j2` |
| Test File | `test_*.py` | `test_user_service.py` |
| Test Func | `test_*` | `test_creates_user()` |
| Env Var | `UPPER_SNAKE_CASE` | `OPENAI_API_KEY` |

## Real Examples from Codebase

### Good Examples

```python
# File: app/services/sample.py
class SampleStreamingService(BaseStreamingService):
    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        self.client = AsyncOpenAI(api_key=api_key)

    def ask_about_city(self, city: str, model: str = "gpt-4o"):
        messages = [
            {"role": "system", "content": "Follow instructions carefully."},
            {"role": "user", "content": get_prompt(city)}
        ]
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model
        )

# File: app/core/streaming/adapters/openai.py
class OpenAIStreamAdapter(StreamAdapter):
    def _build_params(self, messages: List[Dict[str, Any]], **kwargs):
        params = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "stream": True
        }
        return params

# File: tests/test_sample_router.py
def test_ask_about_city_streams_response(monkeypatch):
    stub = StreamingStub(["0:chunk", "e:end"])
    client = build_test_client(monkeypatch, lambda: stub)
    response = client.post("/sample/city", json={"city": "Lisbon"})
    assert response.status_code == 200
```

---

**Next:** [Architecture Patterns](./03-architecture.md) - Learn how components work together
