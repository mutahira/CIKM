from collections import deque

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from fastapi.testclient import TestClient

from app.routers import sample


def build_test_client(monkeypatch, service_factory):
    monkeypatch.setattr(sample, "SampleStreamingService", service_factory)
    app = FastAPI()
    app.include_router(sample.router)
    return TestClient(app)


class StreamingStub:
    def __init__(self, chunks):
        self.calls = deque()
        self._chunks = chunks

    def ask_about_city(self, city, model):
        self.calls.append((city, model))

        async def generator():
            for chunk in self._chunks:
                yield chunk

        return StreamingResponse(generator(), media_type="text/event-stream")

    def stream_story(self, chunk_size=5):
        self.calls.append(("story", chunk_size))

        async def generator():
            for chunk in self._chunks:
                yield chunk

        return StreamingResponse(generator(), media_type="text/event-stream")


def test_show_me_endpoint_returns_prompt(monkeypatch):
    client = build_test_client(monkeypatch, lambda: StreamingStub(["0:hi"]))

    response = client.post("/sample/show/me", json={"city": "Paris"})
    assert response.status_code == 200
    payload = response.json()
    assert payload["success"] is True
    assert "Paris" in payload["prompt"]
    assert payload["data"]["city"] == "Paris"


def test_ask_about_city_streams_response(monkeypatch):
    stub = StreamingStub(["0:chunk", "e:end"])
    client = build_test_client(monkeypatch, lambda: stub)

    response = client.post("/sample/city", json={"city": "Lisbon", "model": "turbo"})

    assert response.status_code == 200
    assert stub.calls.pop() == ("Lisbon", "turbo")
    assert "0:chunk" in response.content.decode()


def test_ask_about_city_handles_value_error(monkeypatch):
    class FailingService:
        def ask_about_city(self, city, model):
            raise ValueError("bad city")

    client = build_test_client(monkeypatch, FailingService)

    response = client.post("/sample/city", json={"city": "Fail", "model": "gpt"})
    assert response.status_code == 500
    assert response.json()["detail"] == "bad city"


def test_ask_about_city_handles_unexpected_error(monkeypatch):
    class FailingService:
        def ask_about_city(self, city, model):
            raise RuntimeError("boom")

    client = build_test_client(monkeypatch, FailingService)

    response = client.post("/sample/city", json={"city": "Fail", "model": "gpt"})
    assert response.status_code == 500
    assert "Failed to process city request" in response.json()["detail"]


def test_stream_story_uses_service(monkeypatch):
    stub = StreamingStub(["0:story"])
    client = build_test_client(monkeypatch, lambda: stub)

    response = client.get("/sample/story", params={"chunk_size": 7})
    assert response.status_code == 200
    assert stub.calls.pop() == ("story", 7)
    body = response.content.decode()
    assert "0:story" in body
