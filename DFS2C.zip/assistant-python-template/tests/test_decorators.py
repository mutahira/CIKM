import logging

from app.core.decorators import log


def test_log_decorator_records_arguments_and_response(caplog):
    caplog.set_level(logging.DEBUG)

    @log(__name__)
    def sample_route(arg1, arg2=None):
        return {"args": (arg1, arg2)}

    result = sample_route("value", arg2="other")

    assert result == {"args": ("value", "other")}
    entries = [record.message for record in caplog.records]
    assert any("Entering route" in msg for msg in entries)
    assert any("Exiting route" in msg for msg in entries)
    assert any("value" in msg for msg in entries)
