import pytest
from fastapi.responses import StreamingResponse

from app.core.streaming.base import StreamChunk
from app.core.streaming.streamers.llm import LLMStreamer


class DummyFormatter:
    def __init__(self):
        self.errors = []

    def format_text_chunk(self, content: str) -> str:
        return f"text:{content}\n"

    def format_finish_chunk(self, finish_reason: str, usage=None) -> str:
        return f"finish:{finish_reason}:{usage}\n"

    def format_error_chunk(self, error: Exception) -> str:
        message = f"error:{error}"
        self.errors.append(message)
        return f"error:{error}\n"


class DummyAdapter:
    def __init__(self, chunks):
        self.chunks = chunks
        self.called_with = None

    async def stream(self, messages, **kwargs):  # pragma: no cover - executed in async
        self.called_with = (messages, kwargs)
        for chunk in self.chunks:
            yield chunk


@pytest.mark.asyncio
async def test_llm_streamer_stream_success():
    chunks = [
        StreamChunk(content="Hello"),
        StreamChunk(
            finish_reason="stop", usage={"promptTokens": 1, "completionTokens": 2}
        ),
    ]
    adapter = DummyAdapter(chunks)
    formatter = DummyFormatter()

    streamer = LLMStreamer(adapter, formatter)
    response = streamer.stream([{"role": "user", "content": "Hi"}], temperature=0.1)

    assert isinstance(response, StreamingResponse)
    assert response.headers["x-vercel-ai-data-stream"] == "v1"

    collected = []
    async for part in response.body_iterator:
        collected.append(part)

    combined = "".join(collected)
    assert "text:Hello" in combined
    assert "finish:stop" in combined

    assert adapter.called_with[1]["temperature"] == 0.1


class FailingAdapter:
    async def stream(self, messages, **kwargs):
        raise RuntimeError("boom")
        yield  # pragma: no cover - needed to mark as async generator


@pytest.mark.asyncio
async def test_llm_streamer_stream_handles_error():
    formatter = DummyFormatter()
    streamer = LLMStreamer(FailingAdapter(), formatter)

    response = streamer.stream([{"role": "user", "content": "Hi"}])

    parts = []
    async for part in response.body_iterator:
        parts.append(part)

    combined = "".join(parts)
    assert "error:boom" in combined
    assert formatter.errors and "error:boom" in formatter.errors[0]
