import argparse


def dummy_function(input: str, output: str) -> None:
    """
    A dummy function to simulate data processing.
    :param input: Path to the input file.
    :param output: Path to the output file.
    """
    print(f"Processing data from {input} to {output}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Data processing script")
    parser.add_argument("--input", type=str, help="Path to the input file")
    parser.add_argument("--output", type=str, help="Path to the output file")
    args = parser.parse_args()
    dummy_function(args.input, args.output)
