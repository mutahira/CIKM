import json
import os
from fastapi.responses import StreamingResponse
from openai import AsyncOpenAI

from app.services.base import BaseStreamingService
from app.templates.builder import PromptBuilder
from app.errors import IncorrectAPIInvocationError

def build_dataset_schema_prompt(files_content: dict) -> str:
    if not files_content:
        raise IncorrectAPIInvocationError("files_content must not be empty")

    return (
        PromptBuilder("schema_generator_prompt.j2")
        .var("files_content", json.dumps(files_content, indent=2))
        .build()
    )


class DatasetSchemaStreamingService(BaseStreamingService):
    def __init__(self):
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable is required")
        self.client = AsyncOpenAI(api_key=api_key)

    def stream_schema(
        self,
        files_content: dict,
        model: str = "gpt-4o"
    ) -> StreamingResponse:

        prompt = build_dataset_schema_prompt(files_content)

        messages = [
            {
                "role": "system",
                "content": "You are a dataset schema generation robot. Always respond in valid JSON-LD."
            },
            {"role": "user", "content": prompt},
        ]

        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model=model
        )
