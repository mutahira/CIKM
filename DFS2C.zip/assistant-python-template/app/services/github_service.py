import requests
from github import Github
from app.github.auth import get_installation_access_token


class GitHubService:
    def __init__(self, installation_id: int):
        self.installation_id = installation_id
        self.token = get_installation_access_token(installation_id)
        self.client = Github(self.token)

    # --------------------------------------------------
    # 1️⃣ Commit or update file (unchanged logic)
    # --------------------------------------------------
    def commit_file(
        self,
        owner: str,
        repo: str,
        branch: str,
        file_path: str,
        content: str,
        commit_message: str = "Add generated notebook"
    ) -> str:
        repository = self.client.get_repo(f"{owner}/{repo}")

        try:
            existing_file = repository.get_contents(file_path, ref=branch)

            repository.update_file(
                path=file_path,
                message=commit_message,
                content=content,
                sha=existing_file.sha,
                branch=branch,
            )

        except Exception:
            repository.create_file(
                path=file_path,
                message=commit_message,
                content=content,
                branch=branch,
            )

        return f"https://github.com/{owner}/{repo}/blob/{branch}/{file_path}"

    # --------------------------------------------------
    # 2️⃣ List repositories for this installation (NEW)
    # --------------------------------------------------
    def list_repositories(self):
        """
        Returns repositories accessible by this GitHub App installation.
        """
        url = "https://api.github.com/installation/repositories"
        headers = {
            "Authorization": f"token {self.token}",
            "Accept": "application/vnd.github+json",
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        return response.json()["repositories"]
