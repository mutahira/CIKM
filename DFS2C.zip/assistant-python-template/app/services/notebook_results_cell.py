import json


def build_result_sender_cell(api_base_url: str, itemId: str) -> str:
    """
    Builds a Python cell that sends `result`
    back to backend along with item_id.
    """

    return f"""
# ===============================
# AUTO-GENERATED RESULT SENDER
# ===============================

import requests
import json
import base64
import os
import io

itemId = "{itemId}"
API_URL = "https://0217-81-14-180-74.ngrok-free.app/results/fetch"  # replace with your actual backend URL

def serialize_result(res):
    # If result is a file path
    if isinstance(res, str) and os.path.exists(res):
        return serialize_file(res)

    # JSON-like
    if isinstance(res, (dict, list)):
        return {{"type": "json", "content": res}}

    # Bytes
    if isinstance(res, bytes):
        encoded = base64.b64encode(res).decode()
        return {{"type": "binary", "content": encoded}}

    # Matplotlib figure
    try:
        if hasattr(res, "savefig"):
            buffer = io.BytesIO()
            res.savefig(buffer, format="png")
            buffer.seek(0)
            encoded = base64.b64encode(buffer.read()).decode()
            return {{"type": "image", "content": encoded}}
    except Exception:
        pass

    # Fallback to text
    return {{"type": "text", "content": str(res)}}


def serialize_file(path):
    ext = os.path.splitext(path)[1].lower()

    with open(path, "rb") as f:
        data = f.read()

    encoded = base64.b64encode(data).decode()

    if ext in [".png", ".jpg", ".jpeg"]:
        return {{"type": "image", "content": encoded}}

    if ext == ".json":
        return {{"type": "json_file", "content": encoded}}

    if ext == ".xml":
        return {{"type": "xml_file", "content": encoded}}

    if ext in [".txt", ".csv"]:
        return {{"type": "text_file", "content": encoded}}

    return {{"type": "file", "content": encoded}}


try:
    payload = {{
        "itemId": itemId,
        "result": serialize_result(result+name),
        "output": name
    }}

    response = requests.post(API_URL, json=payload, timeout=30)
    print("Result sent:", response.status_code)

except Exception as e:
    print("Failed to send result:", str(e))
"""