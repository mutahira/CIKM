import re
from typing import List

def extract_json_from_streamed_chunks(chunks: List[str]) -> str:
    """
    Extract JSON (or JSON-LD) from a list of streamed strings coming from LLM.

    This handles cases where the LLM wraps JSON in Markdown (like ```json ... ```).

    :param chunks: List of strings from streamed response
    :return: A single JSON string
    """
    combined_text = "".join(chunks)

    # Remove Markdown fences (```json ... ```)
    pattern = r"```(?:json)?\s*(.*?)```"
    match = re.search(pattern, combined_text, flags=re.DOTALL)
    if match:
        json_str = match.group(1).strip()
    else:
        # fallback: try to parse entire text
        json_str = combined_text.strip()

    return json_str
