# -*- coding: utf-8 -*-
from pathlib import Path

from fastapi.responses import FileResponse

from app.app_factory import get_application
from dotenv import load_dotenv
load_dotenv()

app = get_application()


@app.get("/")
def root():
    static_dir = Path(__file__).parent / "static"
    return FileResponse(static_dir / "index.html")


@app.get("/demo")
def streaming_demo():
    static_dir = Path(__file__).parent / "static"
    return FileResponse(static_dir / "streaming-demo.html")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
