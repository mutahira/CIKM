from pydantic import BaseModel

class FetchResultRequest(BaseModel):
    user_id: str
    itemId: str