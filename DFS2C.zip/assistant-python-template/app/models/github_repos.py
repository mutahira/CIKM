from pydantic import BaseModel


class GitHubRepo(BaseModel):
    full_name: str
    name: str
    owner: str
    default_branch: str
    private: bool
