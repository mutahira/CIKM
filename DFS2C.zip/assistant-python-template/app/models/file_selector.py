from pydantic import BaseModel, Field
from typing import Any, List, Optional


class FileSelectorRequest(BaseModel):
    """
    Request containing the directory structure metadata.
    """

    directory_structure: dict = Field(
        ...,
        description="Recursive directory structure with files and children",
        examples=[
            {
                "name": "dataset",
                "type": "directory",
                "children": [],
            }
        ],
    )
    model: Optional[str] = Field(
        default="gpt-4o",
        description="LLM model to use",
        examples=["gpt-4o", "gpt-4o-mini"],
    )


class FileSuggestion(BaseModel):
    """
    A single file suggestion returned by the LLM.
    """

    file_path: str = Field(
        ..., description="Path of the file relative to dataset root"
    )
    lines_to_read: int = Field(
        ..., description="Number of lines to read from the file", gt=0
    )
    reason: Optional[str] = Field(
        None, description="Reason why this file was selected"
    )

# Need to map response?

class FileSelectorResponse(BaseModel):
    """
    Final parsed response (non-streaming use cases).
    """

    success: bool = Field(..., description="Indicates if the request was successful")
    suggestions: List[FileSuggestion]
