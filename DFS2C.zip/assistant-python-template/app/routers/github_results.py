from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any
import uuid
import base64

from app.github.pocketbase_client import pb_admin
from app.github.auth2 import get_installation_token
import requests
from app.models.github_results import ResultPayload
from app.services.github_results import upload_to_github
from fastapi import APIRouter, Depends


router = APIRouter(prefix="/results", tags=["notebooks"])




@router.post("/fetch")
def receive_results(payload: ResultPayload):
    try:
        # fetch record by itemId field, not record ID
        record = pb_admin.collection("result_record").get_first_list_item(
            f'itemId="{payload.itemId}"'
        )

        user_id = record.user_id
        owner = record.github_owner
        repo = record.github_repo
        branch = getattr(record, "branch", "main")
        dataset_folder = record.folder_name

        # fetch installation
        installation_record = pb_admin.collection("github_installations").get_first_list_item(
            f'user_id="{user_id}"'
        )
        installation_id = installation_record.installation_id

        # upload
        filename = payload.outputName
        path = f"{dataset_folder}/{filename}"
        content_base64 = payload.result["content"]

        upload_to_github(owner, repo, branch, installation_id, path, content_base64)

        # 4️⃣ Update result_record after successful GitHub upload
        pb_admin.collection("result_record").update(
            record.id,
            {
                "output": filename,   # update output field with uploaded filename
                "status": "uploaded"  # change status from 'waiting' → 'uploaded'
            }
        )

        return {"status": "success", "path": path}

    except Exception as e:
        print("ERROR:", e)
        raise HTTPException(status_code=400, detail=str(e))