from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from app.core.decorators import log
from app.models.schema_generator import DatasetSchemaRequest
from app.services.schema_generator import DatasetSchemaStreamingService

router = APIRouter(
    prefix="/dataset/schema",
    tags=["Dataset Schema Generator"]
)

@router.post(
    "/generate",
    response_class=StreamingResponse
)
@log(__name__)
def stream_dataset_schema(request: DatasetSchemaRequest):
    """
    Streaming endpoint: returns the LLM output as it arrives.
    No parsing or post-processing.
    """
    try:
        service = DatasetSchemaStreamingService()
        return service.stream_schema(
            files_content=request.files_content,
            model=request.model or "gpt-4o"
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to stream schema: {str(e)}")
