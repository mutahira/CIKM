import base64
import requests
from fastapi import APIRouter, Depends
from app.github.keycloak_auth import get_current_user
from app.github.auth2 import get_installation_token
from app.github.utils import get_installation_id_for_user
from app.models.notebook import (
    NotebookGenerateRequest,
    NotebookGenerateResponse,
)
from app.utils.utils import build_notebook
from app.services.fetch_results_table import create_execution_record
from app.services.notebook_results_cell import build_result_sender_cell
import json

router = APIRouter(prefix="/notebooks", tags=["notebooks"])


@router.post("/generate", response_model=NotebookGenerateResponse)
def generate_notebook(
    payload: NotebookGenerateRequest,
    user_id: str = Depends(get_current_user),
):
    # 🟢 0️⃣ Create execution record FIRST
    execution = create_execution_record(
        user_id=user_id,
        github_owner=payload.github_owner,
        github_repo=payload.github_repo,
        branch=payload.branch,
        itemId=payload.itemId,
        datasetFolder=payload.datasetFolder,
    )
    # 1️⃣ Get user's GitHub installation
    installation_id = get_installation_id_for_user(user_id)

    # 2️⃣ Get GitHub access token
    gh_token = get_installation_token(installation_id)

    # 3️⃣ Build notebook
    notebook_content = build_notebook(
     payload.code,
     payload.markdown_intro,
)

    # 3.5️⃣ Create the Result Section
    result_cell_code = build_result_sender_cell(
        api_base_url="https://your-backend-url.com",
        itemId=payload.itemId,
    )

    notebook_json = json.loads(notebook_content)

    # 1. Define the generic Markdown header for the result
    result_header = {
        "cell_type": "markdown",
        "metadata": {},
        "source": [
            "--- \n",
            "### 🚀 Auto-Generated Results Handler\n",
            "This section transmits your analysis results back to the platform."
        ]
    }

    # 2. Define the Code cell
    result_code_cell = {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": result_cell_code.splitlines(True),
    }

    # 3. Append them together at the end of the notebook
    notebook_json["cells"].extend([result_header, result_code_cell])

    notebook_content = json.dumps(notebook_json)


    encoded = base64.b64encode(
        notebook_content.encode()
    ).decode()

    # 4️⃣ Commit to GitHub
    url = (
        f"https://api.github.com/repos/"
        f"{payload.github_owner}/{payload.github_repo}/contents/"
        f"{payload.notebook_path}"
    )

    response = requests.put(
        url,
        headers={
            "Authorization": f"token {gh_token}",
            "Accept": "application/vnd.github+json",
        },
        json={
            "message": "Auto-generated notebook",
            "content": encoded,
            "branch": payload.branch,
        },
    )

    response.raise_for_status()

    # 5️⃣ Build URLs
    github_url = (
        f"https://github.com/{payload.github_owner}/"
        f"{payload.github_repo}/blob/"
        f"{payload.branch}/{payload.notebook_path}"
    )

    colab_url = (
        "https://colab.research.google.com/github/"
        f"{payload.github_owner}/{payload.github_repo}/"
        f"blob/{payload.branch}/{payload.notebook_path}"
    )

    return NotebookGenerateResponse(
        github_url=github_url,
        colab_url=colab_url,
    )
