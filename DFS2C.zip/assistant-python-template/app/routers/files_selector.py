import http

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.core.decorators import log
from app.models.file_selector import FileSelectorRequest
from app.services.file_selector import FileSelectionStreamingService

router = APIRouter(
    prefix="/dataset/files",
    tags=["Dataset File Selector"],
)


@router.post(
    "/selector",
    status_code=http.HTTPStatus.OK,
    response_class=StreamingResponse,
)
@log(__name__)
def suggest_files_to_read(request: FileSelectorRequest):
    """
    Ask the LLM to suggest which files should be read
    and how many lines from each file.

    Example request:
    ```json
    {
      "directory_structure": { ... },
      "model": "gpt-4o"
    }
    ```

    The response is streamed in AI SDK format.
    """
    try:
        service = FileSelectionStreamingService()
        return service.suggest_files_to_read(
            directory_structure=request.directory_structure,
            model=request.model or "gpt-4o",
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to suggest files: {str(e)}",
        )
