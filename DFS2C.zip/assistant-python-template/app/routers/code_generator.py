import http

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from app.core.decorators import log
from app.models.code_generator import CodeGenerationRequest
from app.services.code_generator import CodeGenerationStreamingService


router = APIRouter(
    prefix="/code",
    tags=["Code Generation"],
)


@router.post(
    "/generate",
    status_code=http.HTTPStatus.OK,
    response_class=StreamingResponse,
)
@log(__name__)
def generate_code(request: CodeGenerationRequest):
    """
    Streams executable Python code for answering a question
    using the provided dataset schema.
    """
    try:
        service = CodeGenerationStreamingService()
        return service.generate_code(
            dataset_schema=request.dataset_schema,
            question=request.question,
            model=request.model or "gpt-4o",
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate code: {str(e)}",
        )
