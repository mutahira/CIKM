import http
import logging
from fastapi import APIRouter

from app.models.dataset_files_reader import (
    DatasetFilesRequest,
    DatasetFilesResponse,
)
from app.services.dataset_files_reader import dataset_files_reader

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/dataset/files",
    tags=["Dataset Files Reader"]
)


@router.post(
    "/reader",
    status_code=http.HTTPStatus.OK,
    response_model=DatasetFilesResponse,
)
def load_dataset(request: DatasetFilesRequest):
    """
    Load first N lines of dataset file(s) from local path, URL, or directory.
    """
    try:
        files_content = dataset_files_reader(
            request.path_or_url,
            request.num_lines
        )

        return DatasetFilesResponse(
            success=True,
            files_content=files_content,
            error_message=None
        )

    except Exception as e:
        logger.exception("Failed to load dataset")
        return DatasetFilesResponse(
            success=False,
            files_content=None,
            error_message=str(e)
        )
