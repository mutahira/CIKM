from typing import Any, AsyncGenerator, Dict, List

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionChunk

from app.core.streaming.base import StreamAdapter, StreamChunk


class OpenAIStreamAdapter(StreamAdapter):
    """
    Adapter for OpenAI's streaming API.

    This adapter normalizes OpenAI's streaming response format into
    a common StreamChunk format that can be consumed by any formatter
    """

    def __init__(
        self,
        client: AsyncOpenAI,
        model: str = "gpt-4o",
        temperature: float | None = None,
        max_tokens: int | None = None,
    ):
        """Initialize the OpenAI stream adapter.

        :param client: AsyncOpenAI client instance
        :param model: Model name to use (default: gpt-4o)
        :param temperature: Sampling temperature (optional)
        :param max_tokens: Maximum tokens to generate (optional)
        """
        self.client = client
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    def _build_params(self, messages: List[Dict[str, Any]], **kwargs) -> Dict[str, Any]:
        """
        Build completion parameters with defaults and overrides.

        :param messages: List of message dictionaries
        :param kwargs: Additional parameters to override defaults
        :return: Complete parameter dictionary for OpenAI API
        """
        params = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "stream": True,
            "stream_options": {"include_usage": True},
        }

        # Add optional parameters if configured
        if self.temperature is not None:
            params["temperature"] = kwargs.get("temperature", self.temperature)
        if self.max_tokens is not None:
            params["max_tokens"] = kwargs.get("max_tokens", self.max_tokens)

        # Add any additional kwargs not already in params
        params.update({k: v for k, v in kwargs.items() if k not in params})

        return params

    def _extract_usage(self, chunk: ChatCompletionChunk) -> Dict[str, int] | None:
        """
        Extract usage information from a chunk

        :param chunk: OpenAI chat completion chunk
        :return: Dictionary with token usage or None
        """
        if hasattr(chunk, "usage") and chunk.usage:
            return {
                "promptTokens": chunk.usage.prompt_tokens,
                "completionTokens": chunk.usage.completion_tokens,
            }
        return None

    def _process_content_chunk(self, chunk: ChatCompletionChunk) -> StreamChunk | None:
        """
        Process a chunk containing content

        :param chunk: OpenAI chat completion chunk with choices
        :return: StreamChunk with content or None
        """
        choice = chunk.choices[0]

        # Handle finish reason
        if choice.finish_reason:
            return StreamChunk(
                finish_reason=choice.finish_reason,
                usage=self._extract_usage(chunk),
            )

        # Handle content delta
        if choice.delta.content:
            return StreamChunk(content=choice.delta.content)

        return None

    def _process_usage_chunk(self, chunk: ChatCompletionChunk) -> StreamChunk | None:
        """
        Process a usage-only chunk (typically at end of stream)

        :param chunk: OpenAI chat completion chunk with usage info
        :return: StreamChunk with usage info or None
        """
        usage = self._extract_usage(chunk)
        if usage:
            return StreamChunk(finish_reason="stop", usage=usage)
        return None

    async def stream(
        self, messages: List[Dict[str, Any]], **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Stream responses from OpenAI.

        :param messages: List of message dictionaries in OpenAI format
        :param kwargs: Additional OpenAI-specific parameters (overrides defaults)
        :yields: StreamChunk objects containing the response data
        """
        params = self._build_params(messages, **kwargs)
        stream = await self.client.chat.completions.create(**params)

        async for chunk in stream:
            # Process chunks with choices (content or finish)
            if chunk.choices:
                stream_chunk = self._process_content_chunk(chunk)
                if stream_chunk:
                    yield stream_chunk

            # Process usage-only chunks
            else:
                stream_chunk = self._process_usage_chunk(chunk)
                if stream_chunk:
                    yield stream_chunk
