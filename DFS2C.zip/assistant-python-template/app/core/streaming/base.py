from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Dict, List


class StreamChunk:
    """
    Represents a chunk of data from an LLM stream
    """

    def __init__(
        self,
        content: str | None = None,
        finish_reason: str | None = None,
        usage: Dict[str, int] | None = None,
    ):
        self.content = content
        self.finish_reason = finish_reason
        self.usage = usage


class StreamAdapter(ABC):
    """
    Abstract base class for LLM stream adapters

    Each LLM provider (OpenAI, Anthropic, etc..) should implement this interface
    to normalize their streaming API into a common format.
    """

    @abstractmethod
    async def stream(
        self, messages: List[Dict[str, Any]], **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        Stream responses from the LLM
        :param messages: List of message dictionaries in OpenAI format
        :param kwargs: Additional provider-specific parameters
        :return: AsyncGenerator yielding StreamChunk objects
        """
        pass


class ProtocolFormatter(ABC):
    """
    Abstract base class for protocol formatters

    Formatters convert StreamChunk objects into specific protocol formats
    (e.g., AI SDK protocol, Server-Sent Events, etc.)
    """

    @abstractmethod
    def format_text_chunk(self, content: str) -> str:
        """Format a text content chunk"""
        pass

    @abstractmethod
    def format_finish_chunk(
        self, finish_reason: str, usage: Dict[str, int] | None = None
    ) -> str:
        """Format the final chunk indicating stream completion"""
        pass

    @abstractmethod
    def format_error_chunk(self, error: Exception) -> str:
        """Format an error chunk"""
        pass
