from typing import List, Dict
from difflib import SequenceMatcher
import re

def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()

def fuzzy_group_files(
    files: List[Dict],
    threshold: float = 0.8,
    min_group_size: int = 10,
) -> List[Dict]:
    groups = []
    used = set()

    for i, f in enumerate(files):
        if i in used:
            continue

        group = [f]
        used.add(i)

        for j, other in enumerate(files[i + 1 :], start=i + 1):
            if j in used:
                continue
            if similarity(f["name"], other["name"]) >= threshold:
                group.append(other)
                used.add(j)

        if len(group) >= min_group_size:
            groups.append(group)
        else:
            # return ungrouped files as-is
            for g in group:
                groups.append([g])

    result = []
    for group in groups:
        if len(group) == 1:
            result.append(group[0])
        else:
            result.append({
                "type": "fuzzy_group",
                "count": len(group),
                "sample": [f["name"] for f in group[:3]],
                "pattern_hint": infer_pattern(group),
            })

    return result


def infer_pattern(files: List[Dict]) -> str:
    names = [f["name"] for f in files]
    base = re.sub(r"\d+", "<num>", names[0])
    return base
