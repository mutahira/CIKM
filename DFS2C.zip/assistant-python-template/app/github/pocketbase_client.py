from pocketbase import PocketBase
from dotenv import load_dotenv
import os

load_dotenv()
POCKETBASE_URL = os.getenv("POCKETBASE_URL")
POCKETBASE_ADMIN_EMAIL = os.getenv("POCKETBASE_ADMIN_EMAIL")
POCKETBASE_ADMIN_PASSWORD = os.getenv("POCKETBASE_ADMIN_PASSWORD")

pb_admin = PocketBase(POCKETBASE_URL)

pb_admin.admins.auth_with_password(
    POCKETBASE_ADMIN_EMAIL,
    POCKETBASE_ADMIN_PASSWORD
)

pb_user = PocketBase(POCKETBASE_URL)



