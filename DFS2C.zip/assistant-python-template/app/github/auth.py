from github import GithubIntegration
from app.core.config import settings


def get_installation_access_token(installation_id: int) -> str:
    """
    Securely obtains a GitHub App installation access token
    """
    print("APP ID TYPE:", type(settings.GITHUB_APP_ID))
    print("PRIVATE KEY TYPE:", type(settings.GITHUB_PRIVATE_KEY))

    print("PRIVATE KEY START:")
    print(settings.GITHUB_PRIVATE_KEY[:100])

    print("PRIVATE KEY END:")
    print(settings.GITHUB_PRIVATE_KEY[-100:])

    try:
        integration = GithubIntegration(
    settings.GITHUB_APP_ID,
    settings.GITHUB_PRIVATE_KEY_PATH.strip()
)


        access_token = integration.get_access_token(installation_id)
        return access_token.token
    


    except Exception as e:
        raise RuntimeError(
            f"Failed to get installation token: {e}"
        )
