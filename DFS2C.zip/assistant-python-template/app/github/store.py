# TEMPORARY in-memory storage
# Later replace with DB

INSTALLATIONS = {}
INSTALL_STATES = {}
