from github import Github
import base64


class GitHubClient:
    def __init__(self, installation_token: str):
        self.client = Github(installation_token)

    def commit_file(
        self,
        owner: str,
        repo: str,
        branch: str,
        path: str,
        content: str,
        message: str,
    ):
        repository = self.client.get_repo(f"{owner}/{repo}")

        encoded = base64.b64encode(content.encode()).decode()

        try:
            existing = repository.get_contents(path, ref=branch)
            repository.update_file(
                path=path,
                message=message,
                content=encoded,
                sha=existing.sha,
                branch=branch,
            )
        except Exception:
            repository.create_file(
                path=path,
                message=message,
                content=encoded,
                branch=branch,
            )
