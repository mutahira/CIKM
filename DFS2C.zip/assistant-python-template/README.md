# Assistant Python Template

A production-ready **FastAPI template** for building AI-powered assistants with real-time LLM streaming capabilities. Built with modern Python practices, clean architecture, and comprehensive documentation.

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.118+-green.svg)](https://fastapi.tiangolo.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 🎯 Features

- **🚀 FastAPI Framework** - High-performance async web framework with automatic OpenAPI documentation
- **🌊 LLM Streaming** - Real-time response streaming using AI SDK protocol format
- **🔌 Provider-Agnostic** - Extensible adapter pattern for multiple LLM providers (OpenAI, Anthropic, etc.)
- **📝 Template Engine** - Jinja2-based prompt building with reusable templates
- **🧪 Comprehensive Testing** - Full test suite with pytest, async support, and mocking
- **📦 Clean Architecture** - Layered design with clear separation of concerns
- **🎨 Interactive Demos** - Built-in HTML demos for testing streaming endpoints
- **📚 Extensive Documentation** - Detailed guides for beginners and experts in `/rules` folder
- **🔧 Developer Tools** - Hot reload, code formatting (black), linting (flake8), and type checking

---

## 📋 Requirements

### System Requirements

- **Python**: 3.11 or higher
- **Package Manager**: Poetry (recommended) or pip
- **Operating System**: Linux, macOS, or Windows

### API Keys

- **OpenAI API Key**: Required for LLM streaming features
  - Get your key at [platform.openai.com](https://platform.openai.com/)

---

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone https://gitlab.com/TIBHannover/orkg/tib-aissistant/assistants/templates/assistant-python-template.git
cd assistant-python-template
```

### 2. Install Dependencies

**Using Poetry:**

```bash
# Install Poetry if you haven't already
curl -sSL https://install.python-poetry.org | python3 -

# Install project dependencies
poetry install
```

### 3. Configure Environment Variables

Create a `.env` file in the project root:

```bash
# Required
OPENAI_API_KEY=your-openai-api-key-here
```

You can use the `.env.example` as a basis for your new env file.

Or export directly:

```bash
export OPENAI_API_KEY="your-openai-api-key-here"
```

### 4. Run the Application

**Using Poetry:**

```bash
poetry run uvicorn app.main:app --reload
```

**Using pip:**

```bash
uvicorn app.main:app --reload
```

The server will start at `http://localhost:8000`

### 5. Explore the Application

- **API Documentation**: http://localhost:8000/docs
- **Alternative Docs**: http://localhost:8000/redoc
- **Interactive Demo**: http://localhost:8000/static/streaming-demo.html
- **Sample Endpoint**: http://localhost:8000/sample/city

---

## 📖 Documentation

Comprehensive documentation is available in the [`/rules`](./rules) folder:

| Document | Description |
|----------|-------------|
| [**Overview**](./rules/00-overview.md) | Project introduction, tech stack, and core concepts |
| [**File Structure**](./rules/01-file-structure.md) | Where files belong and how to organize code |
| [**Naming Conventions**](./rules/02-naming-conventions.md) | How to name classes, functions, and files |
| [**Architecture**](./rules/03-architecture.md) | Design patterns and component interactions |
| [**Streaming**](./rules/04-streaming.md) | Deep dive into LLM streaming infrastructure |
| [**Testing**](./rules/05-testing.md) | How to write and run tests |

**For Beginners**: Start with [rules/README.md](./rules/README.md) for a guided learning path.

**Additional Documentation**:
- [openapi.json](./openapi.json) - Auto-generated API specification

---

## 🏗️ Project Structure

```
assistant-python-template/
├── app/                      # Main application code
│   ├── main.py              # Application entry point
│   ├── app_factory.py       # App configuration
│   ├── routers/             # HTTP endpoints
│   ├── services/            # Business logic
│   ├── models/              # Pydantic data models
│   ├── core/                # Core utilities
│   │   ├── decorators.py   # Logging decorators
│   │   └── streaming/      # Streaming infrastructure
│   ├── templates/           # Jinja2 prompt templates
│   └── static/              # HTML demos
├── tests/                   # Test suite
├── rules/                   # Comprehensive documentation
├── pyproject.toml          # Project dependencies
└── README.md               # This file
```

---

## 💻 Usage Examples

### Basic Non-Streaming Endpoint

```bash
curl -X POST http://localhost:8000/sample/show/me \
  -H "Content-Type: application/json" \
  -d '{"city": "Paris"}'
```

### Streaming LLM Response

```bash
curl -X POST http://localhost:8000/sample/city \
  -H "Content-Type: application/json" \
  -d '{"city": "Tokyo", "model": "gpt-4o"}'
```

**Response (AI SDK format):**
```
0:"Tokyo"
0:" is"
0:" the"
0:" capital"
0:" of"
0:" Japan."
e:{"finishReason":"stop","usage":{"promptTokens":45,"completionTokens":150},"isContinued":false}
```

### Python Client Example

```python
import httpx
import json

async def stream_city_info(city: str):
    async with httpx.AsyncClient() as client:
        async with client.stream(
            'POST',
            'http://localhost:8000/sample/city',
            json={"city": city, "model": "gpt-4o"}
        ) as response:
            async for line in response.aiter_lines():
                if not line:
                    continue

                prefix, data = line.split(':', 1)
                if prefix == '0':  # Text chunk
                    print(json.loads(data), end='', flush=True)
                elif prefix == 'e':  # End metadata
                    metadata = json.loads(data)
                    print(f"\n\nTokens used: {metadata['usage']}")
```

---

## 🧪 Testing

### Run All Tests

```bash
# Using Poetry
poetry run pytest

# Using pip
pytest
```

### Run with Coverage

```bash
# Generate coverage report
poetry run pytest --cov=app --cov-report=html

# View report
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Run Specific Tests

```bash
# Run specific file
pytest tests/test_sample_router.py

# Run specific test
pytest tests/test_sample_router.py::test_show_me_endpoint_returns_prompt

# Run tests matching pattern
pytest -k "router"
```

---

## 🛠️ Development

### Code Formatting

```bash
# Format code with black
poetry run black app/

# Sort imports
poetry run isort app/

# Lint with flake8
poetry run flake8 app/
```

### Pre-commit Hooks

```bash
# Install pre-commit hooks
poetry run pre-commit install

# Run manually
poetry run pre-commit run --all-files
```

---

## 🎨 Adding New Features

### Add a New Endpoint

1. **Create Model** in `app/models/`:
```python
class YourRequest(BaseModel):
    param: str = Field(..., description="Your parameter")
```

2. **Create Service** in `app/services/`:
```python
class YourService(BaseStreamingService):
    def process(self, param: str) -> StreamingResponse:
        messages = [{"role": "user", "content": param}]
        return self.create_stream_response(
            client=self.client,
            messages=messages,
            model="gpt-4o"
        )
```

3. **Create Router** in `app/routers/`:
```python
@router.post("/your-endpoint")
@log(__name__)
def your_endpoint(request: YourRequest):
    service = YourService()
    return service.process(request.param)
```

4. **Register Router** in `app/app_factory.py`:
```python
def __configure_routers(app: FastAPI):
    app.include_router(your_router.router)
```

5. **Write Tests** in `tests/`:
```python
def test_your_endpoint(client):
    response = client.post("/your-endpoint", json={"param": "test"})
    assert response.status_code == 200
```

**See [Architecture Documentation](./rules/03-architecture.md) for detailed patterns.**

---

## 🔌 Extending LLM Support

The streaming infrastructure supports multiple LLM providers through adapters.

### Add a New Provider (e.g., Anthropic)

1. **Create Adapter** in `app/core/streaming/adapters/`:
```python
class AnthropicStreamAdapter(StreamAdapter):
    async def stream(self, messages, **kwargs):
        # Implement Anthropic-specific streaming
        async for chunk in self.client.messages.create(...):
            yield StreamChunk(content=chunk.delta.text)
```

2. **Use in Service**:
```python
adapter = AnthropicStreamAdapter(anthropic_client)
formatter = AISdkFormatter()
streamer = LLMStreamer(adapter, formatter)
return streamer.stream(messages)
```

**See [Streaming Documentation](./rules/04-streaming.md) for complete guide.**

---

## 📊 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/sample/show/me` | Non-streaming example endpoint |
| POST | `/sample/city` | Stream LLM response about a city |
| GET | `/sample/story` | Stream non-LLM text content |
| GET | `/docs` | OpenAPI interactive documentation |
| GET | `/redoc` | Alternative API documentation |
| GET | `/static/streaming-demo.html` | Interactive streaming demo |

---

## 🤝 Contributing

We welcome contributions! Please follow these guidelines:

1. **Read the Documentation** - Check [/rules](./rules) for coding standards
2. **Create a Branch** - Use descriptive branch names
3. **Follow Conventions** - Match existing naming and structure patterns
4. **Write Tests** - Add tests for new features
5. **Format Code** - Run `black` and `isort` before committing
6. **Update Docs** - Keep documentation in sync with code changes

### Development Workflow

```bash
# Create feature branch
git checkout -b feature/your-feature-name

# Make changes and test
poetry run pytest

# Format code
poetry run black app/
poetry run isort app/

# Commit changes
git add .
git commit -m "feat: add your feature"

# Push and create merge request
git push origin feature/your-feature-name
```

---

## 📝 Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENAI_API_KEY` | ✅ Yes | - | OpenAI API key for LLM access |
| `LOG_LEVEL` | ❌ No | `INFO` | Logging level (DEBUG, INFO, WARNING, ERROR) |
| `DEFAULT_MODEL` | ❌ No | `gpt-4o` | Default OpenAI model to use |

---

## 🐛 Troubleshooting

### Common Issues

**Issue**: `ValueError: OPENAI_API_KEY required`
- **Solution**: Set the `OPENAI_API_KEY` environment variable

**Issue**: Tests failing with async errors
- **Solution**: Ensure `pytest-asyncio` is installed and `asyncio_mode = "auto"` is set in `pyproject.toml`

**Issue**: Import errors
- **Solution**: Make sure you're in the project root and virtual environment is activated

**Issue**: Streaming not working
- **Solution**: Check that response headers include `Content-Type: text/event-stream`

**For more help**, see [Troubleshooting Guide](./rules/04-streaming.md#troubleshooting)

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---



## 🗺️ Roadmap

- [ ] Add support for more LLM providers (Anthropic, HuggingFace, etc.)
- [ ] Implement caching layer for responses
- [ ] Add conversation history management
- [x] Create Docker deployment configuration
- [ ] Add authentication and rate limiting
- [ ] Implement websocket support
- [ ] Add monitoring and observability tools
